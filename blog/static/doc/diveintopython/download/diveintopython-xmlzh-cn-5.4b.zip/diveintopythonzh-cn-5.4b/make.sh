#! /bin/sh
java -classpath "../common/lib/ant.jar:../common/lib/optional.jar:../common/lib/NetComponents.jar:../common/lib/jaxp.jar:../common/lib/crimson.jar" org.apache.tools.ant.Main $1 $2 $3 $4 $5 $6 $7 $8 $9
